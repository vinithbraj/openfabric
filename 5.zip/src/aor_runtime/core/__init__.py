"""Core contracts and utilities."""
