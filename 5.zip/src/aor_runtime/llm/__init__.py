"""LLM integration layer."""
